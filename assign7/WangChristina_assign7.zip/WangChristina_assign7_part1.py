"""
Christina Wang	1/27/22	CSCI-UA 2 - 006
Assignment #7 Problem #1
"""
